var fullName = "salman";
var age = 33;
var statusDetails = true;
var digits = "salman";
digits = 33;
console.log(fullName);
