let fullName:string = "salman";
let age:number = 33;
let statusDetails:boolean = true;
let digits:any = "salman";
digits = 33;
console.log(fullName);