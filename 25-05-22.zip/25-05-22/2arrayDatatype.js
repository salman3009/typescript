var stringArray = ["salman", "akash", "ram"];
var numberArray = [22, 3, 44, 55, 222];
var booleanArray = [true, false, true, false];
var anyArray = ["salman", 33, true];
stringArray.push("details");
