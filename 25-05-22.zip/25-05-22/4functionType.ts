function addition(a:number,b:number):number{
    return a+b;
}

addition(3,3);

function result(input:number[]):number[]{
    return input;
}

result([444,44,44]);


const subtraction=(a:number,b:number):number=>{
    return a-b;
}
subtraction(33,33);