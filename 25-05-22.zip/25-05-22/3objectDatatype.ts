let address:{doorNO:number,fullName:string,flag:boolean}={
    doorNO:33,
    fullName:"salman",
    flag:true
};


let salary:{account:{type:string,amount:number},age:number,address:string}={
    account:{
        type:"saving",
        amount:333
    },
    age:44,
    address:"chennai"
};
