var address = {
    doorNO: 33,
    fullName: "salman",
    flag: true
};
var salary = {
    account: {
        type: "saving",
        amount: 333
    },
    age: "44",
    address: "chennai"
};
