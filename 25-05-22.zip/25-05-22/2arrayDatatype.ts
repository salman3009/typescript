let stringArray:string[]=["salman","akash","ram"];
let numberArray:number[]=[22,3,44,55,222];
let booleanArray:boolean[]=[true,false,true,false];
let anyArray:any[]=["salman",33,true];

stringArray.push("details");