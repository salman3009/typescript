var fullName = "salman";
var lastName = "g";
var result = "Hi My name is " + fullName + " and my lastname is " + lastName;
console.log(result);
