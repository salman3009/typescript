
let fullName:string = "salman";
let lastName:string = "g";

let result:string = `Hi My name is ${fullName} and my lastname is ${lastName}`;

console.log(result);